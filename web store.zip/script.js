// Data produk APK Premium yang diperbarui
const apkProducts = [
    { id: 1, name:"Alight Motion", price: "3.000", icon: "fas fa-mobile-alt", detail: "Privat 1 Tahun." },
    { id: 2, name: "Bstation", price: "5.500", icon: "fas fa-mobile-alt", detail: "3b shar 9.5k - 1y shar 13k - 1y priv 34k" },
    { id: 3, name: "Canva", price: "1k", icon: "fas fa-mobile-alt", detail: "2b invite 1.7k - 1b admin 4k - - 1b owner 5k." },
    { id: 4, name: "Capcut", price: "2.000", icon: "fas fa-mobile-alt", detail: "shar 3u 1b 4k - priv 7h 5k - priv 1b 9k." },
    { id: 5, name: "Fizzo", price: "5.500", icon: "fas fa-mobile-alt", detail: "shar 3b 10k - shar 6b 15k." },
    { id: 6, name: "Hbogo", price: "8.500", icon: "fas fa-mobile-alt", detail: "Aplikasi premium dengan fitur lengkap." },
    { id: 7, name: "Ibis Paint", price: "6.100", icon: "fas fa-mobile-alt", detail: "shar 1y ios 13.1k." },
    { id: 8, name: "Loklok", price: "8.700", icon: "fas fa-mobile-alt", detail: "1b priv 19.8k." },
    { id: 9, name: "Meitu", price: "-", icon: "fas fa-mobile-alt", detail: "Aplikasi premium dengan fitur lengkap." },
    { id: 10, name: "Netflix", price: "11.000", icon: "fas fa-mobile-alt", detail: "1b2u shar 19.1k - semipriv 21.1k." },
    { id: 11, name: "Spotify", price: "12.000", icon: "fas fa-mobile-alt", detail: "fullgaransi 1b 16.1k - famplan reg mix 1b 17.5k - (akun dari seller,garansi) - famplan reg indo 2b 30.1k - 3b 43.5k (fullgaransi)." },
    { id: 12, name: "𓏲⋆ ִֶָ ๋𓂃 ⋆ ωׄᧉׅɬׅ𝘃꯭", price: "3.000", icon: "fas fa-mobile-alt", detail: "Aplikasi premium dengan fitur lengkap." },
    { id: 13, name: "𓏲⋆ ִֶָ ๋𓂃 ⋆ ωׄꪱ๋𝗯𝗎ׄ𝗸𝗎ׄ", price: "3.000", icon: "fas fa-mobile-alt", detail: "Aplikasi premium dengan fitur lengkap." },
    { id: 14, name: "𓏲⋆ ִֶָ ๋𓂃 ⋆ ყׄɬׅ", price: "3.000", icon: "fas fa-mobile-alt", detail: "Aplikasi premium dengan fitur lengkap." }
];

const scriptBotProducts = [
    { id: 1, name: "Script Bot MD Jaga Grup", price: "35.000", icon: "fas fa-shield-alt", detail: "Bot otomatis untuk menjaga grup WhatsApp dari spam dan anggota tidak diinginkan. Fitur: auto kick, anti link, anti spam, dll." },
    { id: 2, name: "Script JPM", price: "10.000", icon: "fas fa-bolt", detail: "Bot untuk game online dengan fitur auto farm dan auto quest. Kompatibel dengan berbagai game populer." }
];

const presetProducts = [
    { 
        id: 1, 
        name: "Preset GFX Premium", 
        price: "49.000", 
        image: "https://files.catbox.moe/pa4l58.jpg",
        detail: "Koleksi lengkap preset GFX profesional untuk desain grafis Anda. Termasuk 50+ preset untuk berbagai kebutuhan desain: poster, banner, media sosial, dan lainnya. Preset ini kompatibel dengan Photoshop, Illustrator, dan Canva." 
    },
    { 
        id: 2, 
        name: "Preset Lightroom Pro", 
        price: "39.000", 
        icon: "fas fa-camera",
        detail: "50+ preset Lightroom untuk fotografer profesional. Memberikan hasil instan yang memukau untuk berbagai jenis foto: landscape, portrait, street photography, dan lainnya." 
    },
    { 
        id: 3, 
        name: "Preset Video Premiere Pro", 
        price: "59.000", 
        icon: "fas fa-video",
        detail: "Koleksi preset untuk Adobe Premiere Pro. Termasuk transisi, efek warna, dan template judul profesional. Cocok untuk content creator dan videographer." 
    }
];

// Data produk Suntik Sosmed
const suntikSosmedProducts = [
    // Instagram Followers
    { id: 1, name: "Instagram Followers: 100", price: "5.000", icon: "fab fa-instagram", detail: "Layanan Instagram Followers: 100 Followers" },
    { id: 2, name: "Instagram Followers: 200", price: "6.000", icon: "fab fa-instagram", detail: "Layanan Instagram Followers: 200 Followers" },
    { id: 3, name: "Instagram Followers: 300", price: "9.000", icon: "fab fa-instagram", detail: "Layanan Instagram Followers: 300 Followers" },
    { id: 4, name: "Instagram Followers: 400", price: "12.000", icon: "fab fa-instagram", detail: "Layanan Instagram Followers: 400 Followers" },
    { id: 5, name: "Instagram Followers: 500", price: "14.000", icon: "fab fa-instagram", detail: "Layanan Instagram Followers: 500 Followers" },
    { id: 6, name: "Instagram Followers: 600", price: "17.000", icon: "fab fa-instagram", detail: "Layanan Instagram Followers: 600 Followers" },
    { id: 7, name: "Instagram Followers: 700", price: "19.000", icon: "fab fa-instagram", detail: "Layanan Instagram Followers: 700 Followers" },
    { id: 8, name: "Instagram Followers: 800", price: "22.000", icon: "fab fa-instagram", detail: "Layanan Instagram Followers: 800 Followers" },
    { id: 9, name: "Instagram Followers: 900", price: "25.000", icon: "fab fa-instagram", detail: "Layanan Instagram Followers: 900 Followers" },
    { id: 10, name: "Instagram Followers: 1000", price: "29.500", icon: "fab fa-instagram", detail: "Layanan Instagram Followers: 1000 Followers" },
    
    // Instagram Like
    { id: 11, name: "Instagram Like: 4000", price: "4.000", icon: "fab fa-instagram", detail: "Layanan Instagram Like: 4000 Likes" },
    { id: 12, name: "Instagram Like: 5000", price: "5.000", icon: "fab fa-instagram", detail: "Layanan Instagram Like: 5000 Likes" },
    { id: 13, name: "Instagram Like: 6000", price: "6.000", icon: "fab fa-instagram", detail: "Layanan Instagram Like: 6000 Likes" },
    { id: 14, name: "Instagram Like: 7000", price: "7.000", icon: "fab fa-instagram", detail: "Layanan Instagram Like: 7000 Likes" },
    { id: 15, name: "Instagram Like: 8000", price: "8.000", icon: "fab fa-instagram", detail: "Layanan Instagram Like: 8000 Likes" },
    { id: 16, name: "Instagram Like: 9000", price: "9.000", icon: "fab fa-instagram", detail: "Layanan Instagram Like: 9000 Likes" },
    { id: 17, name: "Instagram Like: 10000", price: "10.000", icon: "fab fa-instagram", detail: "Layanan Instagram Like: 10000 Likes" },
    { id: 18, name: "Instagram Like: 50000", price: "45.000", icon: "fab fa-instagram", detail: "Layanan Instagram Like: 50000 Likes" },
    { id: 19, name: "Instagram Like: 100000", price: "85.000", icon: "fab fa-instagram", detail: "Layanan Instagram Like: 100000 Likes" },
    
    // TikTok Followers
    { id: 20, name: "TikTok Followers: 100", price: "5.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Followers: 100 Followers" },
    { id: 21, name: "TikTok Followers: 200", price: "8.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Followers: 200 Followers" },
    { id: 22, name: "TikTok Followers: 300", price: "11.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Followers: 300 Followers" },
    { id: 23, name: "TikTok Followers: 400", price: "14.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Followers: 400 Followers" },
    { id: 24, name: "TikTok Followers: 500", price: "17.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Followers: 500 Followers" },
    { id: 25, name: "TikTok Followers: 600", price: "20.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Followers: 600 Followers" },
    { id: 26, name: "TikTok Followers: 700", price: "23.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Followers: 700 Followers" },
    { id: 27, name: "TikTok Followers: 800", price: "26.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Followers: 800 Followers" },
    { id: 28, name: "TikTok Followers: 900", price: "29.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Followers: 900 Followers" },
    { id: 29, name: "TikTok Followers: 1000", price: "32.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Followers: 1000 Followers" },
    
    // TikTok Like
    { id: 30, name: "TikTok Like: 1000", price: "5.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Like: 1000 Likes" },
    { id: 31, name: "TikTok Like: 2000", price: "8.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Like: 2000 Likes" },
    { id: 32, name: "TikTok Like: 3000", price: "10.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Like: 3000 Likes" },
    { id: 33, name: "TikTok Like: 4000", price: "12.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Like: 4000 Likes" },
    { id: 34, name: "TikTok Like: 5000", price: "15.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Like: 5000 Likes" },
    { id: 35, name: "TikTok Like: 6000", price: "18.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Like: 6000 Likes" },
    { id: 36, name: "TikTok Like: 7000", price: "19.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Like: 7000 Likes" },
    { id: 37, name: "TikTok Like: 8000", price: "21.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Like: 8000 Likes" },
    { id: 38, name: "TikTok Like: 9000", price: "22.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Like: 9000 Likes" },
    { id: 39, name: "TikTok Like: 10000", price: "25.000", icon: "fab fa-tiktok", detail: "Layanan TikTok Like: 10000 Likes" }
];

// Data produk Top Up Free Fire
const freeFireProducts = [
    { id: 1, name: "Diamond Free Fire: 50", price: "7.500", icon: "fas fa-diamond", detail: "50 Diamond Free Fire" },
    { id: 2, name: "Diamond Free Fire: 100", price: "15.000", icon: "fas fa-diamond", detail: "100 Diamond Free Fire" },
    { id: 3, name: "Diamond Free Fire: 150", price: "21.500", icon: "fas fa-diamond", detail: "150 Diamond Free Fire" },
    { id: 4, name: "Diamond Free Fire: 200+10", price: "28.000", icon: "fas fa-diamond", detail: "210 Diamond Free Fire (200+10 bonus)" },
    { id: 5, name: "Diamond Free Fire: 300", price: "42.000", icon: "fas fa-diamond", detail: "300 Diamond Free Fire" },
    { id: 6, name: "Diamond Free Fire: 500", price: "70.000", icon: "fas fa-diamond", detail: "500 Diamond Free Fire" },
    { id: 7, name: "Diamond Free Fire: 1000", price: "145.000", icon: "fas fa-diamond", detail: "1000 Diamond Free Fire" },
    { id: 8, name: "Diamond Free Fire: 2000", price: "270.000", icon: "fas fa-diamond", detail: "2000 Diamond Free Fire" }
];

// Data produk Top Up Robux
const robuxProducts = [
    { id: 1, name: "Robux: 80", price: "20.000", icon: "fas fa-gamepad", detail: "80 Robux untuk game Roblox" },
    { id: 2, name: "Robux: 160", price: "38.000", icon: "fas fa-gamepad", detail: "160 Robux untuk game Roblox" },
    { id: 3, name: "Robux: 240", price: "52.000", icon: "fas fa-gamepad", detail: "240 Robux untuk game Roblox" },
    { id: 4, name: "Robux: 320", price: "68.000", icon: "fas fa-gamepad", detail: "320 Robux untuk game Roblox" },
    { id: 5, name: "Robux: 400", price: "80.000", icon: "fas fa-gamepad", detail: "400 Robux untuk game Roblox" },
    { id: 6, name: "Robux: 500", price: "85.000", icon: "fas fa-gamepad", detail: "500 Robux untuk game Roblox" }
];

// Data produk Nokos (Nomor Kosong)
const nokosProducts = [
    { id: 1, name: "Nokos indo", price: "6.000", icon: "fas fa-phone", detail: "Nomor kosong Indonesia" },
    { id: 2, name: "Nokos kanada", price: "17.000", icon: "fas fa-phone", detail: "Nomor kosong Kanada" },
    { id: 3, name: "Nokos brazil", price: "16.000", icon: "fas fa-phone", detail: "Nomor kosong Brazil" },
    { id: 4, name: "Nokos kolombia", price: "12.000", icon: "fas fa-phone", detail: "Nomor kosong Kolombia" },
    { id: 5, name: "Nokos Malaysia", price: "10.000", icon: "fas fa-phone", detail: "Nomor kosong Malaysia" },
    { id: 6, name: "Nokos Thailand", price: "11.000", icon: "fas fa-phone", detail: "Nomor kosong Thailand" },
    { id: 7, name: "Nokos India", price: "15.000", icon: "fas fa-phone", detail: "Nomor kosong India" },
    { id: 8, name: "Nokos england", price: "12.000", icon: "fas fa-phone", detail: "Nomor kosong Inggris" },
    { id: 9, name: "Nokos lithuania", price: "17.000", icon: "fas fa-phone", detail: "Nomor kosong Lithuania" },
    { id: 10, name: "Nokos polandia", price: "16.000", icon: "fas fa-phone", detail: "Nomor kosong Polandia" },
    { id: 11, name: "Nokos spanyol", price: "16.000", icon: "fas fa-phone", detail: "Nomor kosong Spanyol" },
    { id: 12, name: "Nokos Nigeria", price: "17.000", icon: "fas fa-phone", detail: "Nomor kosong Nigeria" }
];

// DOM elements
const apkPremiumLink = document.getElementById('apk-premium-link');
const scriptBotLink = document.getElementById('script-bot-link');
const presetLink = document.getElementById('preset-link');
const suntikSosmedLink = document.getElementById('suntik-sosmed-link');
const freeFireLink = document.getElementById('free-fire-link');
const robuxLink = document.getElementById('robux-link');
const nokosLink = document.getElementById('nokos-link');

const apkPremiumPage = document.getElementById('apk-premium-page');
const scriptBotPage = document.getElementById('script-bot-page');
const presetPage = document.getElementById('preset-page');
const suntikSosmedPage = document.getElementById('suntik-sosmed-page');
const freeFirePage = document.getElementById('free-fire-page');
const robuxPage = document.getElementById('robux-page');
const nokosPage = document.getElementById('nokos-page');

const backToMainApk = document.getElementById('back-to-main-apk');
const backToMainScript = document.getElementById('back-to-main-script');
const backToMainPreset = document.getElementById('back-to-main-preset');
const backToMainSuntik = document.getElementById('back-to-main-suntik');
const backToMainFreeFire = document.getElementById('back-to-main-free-fire');
const backToMainRobux = document.getElementById('back-to-main-robux');
const backToMainNokos = document.getElementById('back-to-main-nokos');

const mainContent = document.querySelector('.container');
const heroSection = document.querySelector('.hero');
const mainProducts = document.getElementById('main-products');

const apkProductsContainer = document.getElementById('apk-products-container');
const scriptBotContainer = document.getElementById('script-bot-container');
const presetContainer = document.getElementById('preset-container');
const suntikSosmedContainer = document.getElementById('suntik-sosmed-container');
const freeFireContainer = document.getElementById('free-fire-container');
const robuxContainer = document.getElementById('robux-container');
const nokosContainer = document.getElementById('nokos-container');

const allProductsLink = document.getElementById('all-products-link');

const footerApkLink = document.getElementById('footer-apk-link');
const footerScriptLink = document.getElementById('footer-script-link');
const footerPresetLink = document.getElementById('footer-preset-link');
const footerSuntikLink = document.getElementById('footer-suntik-link');
const footerFreeFireLink = document.getElementById('footer-free-fire-link');
const footerRobuxLink = document.getElementById('footer-robux-link');
const footerNokosLink = document.getElementById('footer-nokos-link');

const paymentModal = document.getElementById('payment-modal');
const closeModal = document.getElementById('close-modal');
const whatsappButton = document.getElementById('whatsapp-button');

// Show APK Premium page
function showApkPage() {
    heroSection.style.display = 'none';
    mainContent.style.display = 'none';
    scriptBotPage.style.display = 'none';
    presetPage.style.display = 'none';
    suntikSosmedPage.style.display = 'none';
    freeFirePage.style.display = 'none';
    robuxPage.style.display = 'none';
    nokosPage.style.display = 'none';
    apkPremiumPage.style.display = 'block';
    
    // Update active category
    document.querySelectorAll('.category-list a').forEach(link => {
        link.classList.remove('active-category');
    });
    apkPremiumLink.classList.add('active-category');
    
    // Scroll to top
    window.scrollTo(0, 0);
}

// Show Script Bot page
function showScriptBotPage() {
    heroSection.style.display = 'none';
    mainContent.style.display = 'none';
    apkPremiumPage.style.display = 'none';
    presetPage.style.display = 'none';
    suntikSosmedPage.style.display = 'none';
    freeFirePage.style.display = 'none';
    robuxPage.style.display = 'none';
    nokosPage.style.display = 'none';
    scriptBotPage.style.display = 'block';
    
    // Update active category
    document.querySelectorAll('.category-list a').forEach(link => {
        link.classList.remove('active-category');
    });
    scriptBotLink.classList.add('active-category');
    
    // Scroll to top
    window.scrollTo(0, 0);
}

// Show Preset page
function showPresetPage() {
    heroSection.style.display = 'none';
    mainContent.style.display = 'none';
    apkPremiumPage.style.display = 'none';
    scriptBotPage.style.display = 'none';
    suntikSosmedPage.style.display = 'none';
    freeFirePage.style.display = 'none';
    robuxPage.style.display = 'none';
    nokosPage.style.display = 'none';
    presetPage.style.display = 'block';
    
    // Update active category
    document.querySelectorAll('.category-list a').forEach(link => {
        link.classList.remove('active-category');
    });
    presetLink.classList.add('active-category');
    
    // Scroll to top
    window.scrollTo(0, 0);
}

// Show Suntik Sosmed page
function showSuntikSosmedPage() {
    heroSection.style.display = 'none';
    mainContent.style.display = 'none';
    apkPremiumPage.style.display = 'none';
    scriptBotPage.style.display = 'none';
    presetPage.style.display = 'none';
    freeFirePage.style.display = 'none';
    robuxPage.style.display = 'none';
    nokosPage.style.display = 'none';
    suntikSosmedPage.style.display = 'block';
    
    // Update active category
    document.querySelectorAll('.category-list a').forEach(link => {
        link.classList.remove('active-category');
    });
    suntikSosmedLink.classList.add('active-category');
    
    // Scroll to top
    window.scrollTo(0, 0);
}

// Show Free Fire page
function showFreeFirePage() {
    heroSection.style.display = 'none';
    mainContent.style.display = 'none';
    apkPremiumPage.style.display = 'none';
    scriptBotPage.style.display = 'none';
    presetPage.style.display = 'none';
    suntikSosmedPage.style.display = 'none';
    robuxPage.style.display = 'none';
    nokosPage.style.display = 'none';
    freeFirePage.style.display = 'block';
    
    // Update active category
    document.querySelectorAll('.category-list a').forEach(link => {
        link.classList.remove('active-category');
    });
    freeFireLink.classList.add('active-category');
    
    // Scroll to top
    window.scrollTo(0, 0);
}

// Show Robux page
function showRobuxPage() {
    heroSection.style.display = 'none';
    mainContent.style.display = 'none';
    apkPremiumPage.style.display = 'none';
    scriptBotPage.style.display = 'none';
    presetPage.style.display = 'none';
    suntikSosmedPage.style.display = 'none';
    freeFirePage.style.display = 'none';
    nokosPage.style.display = 'none';
    robuxPage.style.display = 'block';
    
    // Update active category
    document.querySelectorAll('.category-list a').forEach(link => {
        link.classList.remove('active-category');
    });
    robuxLink.classList.add('active-category');
    
    // Scroll to top
    window.scrollTo(0, 0);
}

// Show Nokos page
function showNokosPage() {
    heroSection.style.display = 'none';
    mainContent.style.display = 'none';
    apkPremiumPage.style.display = 'none';
    scriptBotPage.style.display = 'none';
    presetPage.style.display = 'none';
    suntikSosmedPage.style.display = 'none';
    freeFirePage.style.display = 'none';
    robuxPage.style.display = 'none';
    nokosPage.style.display = 'block';
    
    // Update active category
    document.querySelectorAll('.category-list a').forEach(link => {
        link.classList.remove('active-category');
    });
    nokosLink.classList.add('active-category');
    
    // Scroll to top
    window.scrollTo(0, 0);
}

// Back to main page
function backToMain() {
    heroSection.style.display = 'block';
    mainContent.style.display = 'flex';
    apkPremiumPage.style.display = 'none';
    scriptBotPage.style.display = 'none';
    presetPage.style.display = 'none';
    suntikSosmedPage.style.display = 'none';
    freeFirePage.style.display = 'none';
    robuxPage.style.display = 'none';
    nokosPage.style.display = 'none';
    
    // Reset active category to "All Products"
    document.querySelectorAll('.category-list a').forEach(link => {
        link.classList.remove('active-category');
    });
    allProductsLink.classList.add('active-category');
    
    // Scroll to top
    window.scrollTo(0, 0);
}

// Toggle detail
function toggleDetail(button) {
    const card = button.closest('.category-card');
    const detail = card.querySelector('.category-detail');
    const isExpanded = detail.classList.contains('expanded');
    
    if (isExpanded) {
        detail.classList.remove('expanded');
        button.textContent = 'Detail';
        button.classList.remove('expanded');
    } else {
        detail.classList.add('expanded');
        button.textContent = 'Sembunyikan';
        button.classList.add('expanded');
    }
}

// Show payment modal
function showPaymentModal(productName, price) {
    paymentModal.style.display = 'flex';
    document.body.style.overflow = 'hidden'; // Prevent scrolling
}

// Close payment modal
function closePaymentModal() {
    paymentModal.style.display = 'none';
    document.body.style.overflow = 'auto'; // Enable scrolling
}

// Generate APK products
function generateApkProducts() {
    apkProductsContainer.innerHTML = '';
    
    apkProducts.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'category-card';
        productCard.innerHTML = `
            <div class="category-icon">
                <i class="${product.icon}"></i>
            </div>
            <div class="category-info">
                <div class="category-name">${product.name}</div>
                <div class="category-detail">
                    ${product.detail}
                </div>
                <div class="category-price">Rp ${product.price}</div>
                <div class="category-actions">
                    <button class="buy-button" data-id="${product.id}" data-name="${product.name}" data-price="${product.price}">Beli Sekarang</button>
                    <button class="detail-button" onclick="toggleDetail(this)">Detail</button>
                </div>
            </div>
        `;
        apkProductsContainer.appendChild(productCard);
    });
    
    // Add event listeners to buy buttons
    document.querySelectorAll('#apk-products-container .buy-button').forEach(button => {
        button.addEventListener('click', function() {
            const productName = this.getAttribute('data-name');
            const price = this.getAttribute('data-price');
            showPaymentModal(productName, price);
        });
    });
}

// Generate Script Bot products
function generateScriptBotProducts() {
    scriptBotContainer.innerHTML = '';
    
    scriptBotProducts.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'category-card';
        productCard.innerHTML = `
            <div class="category-icon">
                <i class="${product.icon}"></i>
            </div>
            <div class="category-info">
                <div class="category-name">${product.name}</div>
                <div class="category-detail">
                    ${product.detail}
                </div>
                <div class="category-price">Rp ${product.price}</div>
                <div class="category-actions">
                    <button class="buy-button" data-id="${product.id}" data-name="${product.name}" data-price="${product.price}">Beli Sekarang</button>
                    <button class="detail-button" onclick="toggleDetail(this)">Detail</button>
                </div>
            </div>
        `;
        scriptBotContainer.appendChild(productCard);
    });
    
    // Add event listeners to buy buttons
    document.querySelectorAll('#script-bot-container .buy-button').forEach(button => {
        button.addEventListener('click', function() {
            const productName = this.getAttribute('data-name');
            const price = this.getAttribute('data-price');
            showPaymentModal(productName, price);
        });
    });
}

// Generate Preset products
function generatePresetProducts() {
    presetContainer.innerHTML = '';
    
    presetProducts.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'category-card';
        
        // Use image if available, otherwise use icon
        const mediaContent = product.image 
            ? `<img src="${product.image}" alt="${product.name}">`
            : `<i class="${product.icon}"></i>`;
        
        productCard.innerHTML = `
            <div class="category-icon">
                ${mediaContent}
            </div>
            <div class="category-info">
                <div class="category-name">${product.name}</div>
                <div class="category-detail">
                    ${product.detail}
                </div>
                <div class="category-price">Rp ${product.price}</div>
                <div class="category-actions">
                    <button class="buy-button" data-id="${product.id}" data-name="${product.name}" data-price="${product.price}">Beli Sekarang</button>
                    <button class="detail-button" onclick="toggleDetail(this)">Detail</button>
                </div>
            </div>
        `;
        presetContainer.appendChild(productCard);
    });
    
    // Add event listeners to buy buttons
    document.querySelectorAll('#preset-container .buy-button').forEach(button => {
        button.addEventListener('click', function() {
            const productName = this.getAttribute('data-name');
            const price = this.getAttribute('data-price');
            showPaymentModal(productName, price);
        });
    });
}

// Generate Suntik Sosmed products
function generateSuntikSosmedProducts() {
    suntikSosmedContainer.innerHTML = '';
    
    suntikSosmedProducts.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'category-card';
        productCard.innerHTML = `
            <div class="category-icon">
                <i class="${product.icon}"></i>
            </div>
            <div class="category-info">
                <div class="category-name">${product.name}</div>
                <div class="category-detail">
                    ${product.detail}
                </div>
                <div class="category-price">Rp ${product.price}</div>
                <div class="category-actions">
                    <button class="buy-button" data-id="${product.id}" data-name="${product.name}" data-price="${product.price}">Beli Sekarang</button>
                    <button class="detail-button" onclick="toggleDetail(this)">Detail</button>
                </div>
            </div>
        `;
        suntikSosmedContainer.appendChild(productCard);
    });
    
    // Add event listeners to buy buttons
    document.querySelectorAll('#suntik-sosmed-container .buy-button').forEach(button => {
        button.addEventListener('click', function() {
            const productName = this.getAttribute('data-name');
            const price = this.getAttribute('data-price');
            showPaymentModal(productName, price);
        });
    });
}

// Generate Free Fire products
function generateFreeFireProducts() {
    freeFireContainer.innerHTML = '';
    
    freeFireProducts.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'category-card';
        productCard.innerHTML = `
            <div class="category-icon free-fire-icon">
                <i class="${product.icon}"></i>
            </div>
            <div class="category-info">
                <div class="category-name">${product.name}</div>
                <div class="category-detail">
                    ${product.detail}
                </div>
                <div class="category-price free-fire-price">Rp ${product.price}</div>
                <div class="category-actions">
                    <button class="buy-button free-fire-button" data-id="${product.id}" data-name="${product.name}" data-price="${product.price}">Beli Sekarang</button>
                    <button class="detail-button" onclick="toggleDetail(this)">Detail</button>
                </div>
            </div>
        `;
        freeFireContainer.appendChild(productCard);
    });
    
    // Add event listeners to buy buttons
    document.querySelectorAll('#free-fire-container .buy-button').forEach(button => {
        button.addEventListener('click', function() {
            const productName = this.getAttribute('data-name');
            const price = this.getAttribute('data-price');
            showPaymentModal(productName, price);
        });
    });
}

// Generate Robux products
function generateRobuxProducts() {
    robuxContainer.innerHTML = '';
    
    robuxProducts.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'category-card';
        productCard.innerHTML = `
            <div class="category-icon robux-icon">
                <i class="${product.icon}"></i>
            </div>
            <div class="category-info">
                <div class="category-name">${product.name}</div>
                <div class="category-detail">
                    ${product.detail}
                </div>
                <div class="category-price robux-price">Rp ${product.price}</div>
                <div class="category-actions">
                    <button class="buy-button robux-button" data-id="${product.id}" data-name="${product.name}" data-price="${product.price}">Beli Sekarang</button>
                    <button class="detail-button" onclick="toggleDetail(this)">Detail</button>
                </div>
            </div>
        `;
        robuxContainer.appendChild(productCard);
    });
    
    // Add event listeners to buy buttons
    document.querySelectorAll('#robux-container .buy-button').forEach(button => {
        button.addEventListener('click', function() {
            const productName = this.getAttribute('data-name');
            const price = this.getAttribute('data-price');
            showPaymentModal(productName, price);
        });
    });
}

// Generate Nokos products
function generateNokosProducts() {
    nokosContainer.innerHTML = '';
    
    nokosProducts.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'category-card';
        productCard.innerHTML = `
            <div class="category-icon nokos-icon">
                <i class="${product.icon}"></i>
            </div>
            <div class="category-info">
                <div class="category-name">${product.name}</div>
                <div class="category-detail">
                    ${product.detail}
                </div>
                <div class="category-price nokos-price">Rp ${product.price}</div>
                <div class="category-actions">
                    <button class="buy-button nokos-button" data-id="${product.id}" data-name="${product.name}" data-price="${product.price}">Beli Sekarang</button>
                    <button class="detail-button" onclick="toggleDetail(this)">Detail</button>
                </div>
            </div>
        `;
        nokosContainer.appendChild(productCard);
    });
    
    // Add event listeners to buy buttons
    document.querySelectorAll('#nokos-container .buy-button').forEach(button => {
        button.addEventListener('click', function() {
            const productName = this.getAttribute('data-name');
            const price = this.getAttribute('data-price');
            showPaymentModal(productName, price);
        });
    });
}

// Event listeners
apkPremiumLink.addEventListener('click', function(e) {
    e.preventDefault();
    showApkPage();
});

scriptBotLink.addEventListener('click', function(e) {
    e.preventDefault();
    showScriptBotPage();
});

presetLink.addEventListener('click', function(e) {
    e.preventDefault();
    showPresetPage();
});

suntikSosmedLink.addEventListener('click', function(e) {
    e.preventDefault();
    showSuntikSosmedPage();
});

freeFireLink.addEventListener('click', function(e) {
    e.preventDefault();
    showFreeFirePage();
});

robuxLink.addEventListener('click', function(e) {
    e.preventDefault();
    showRobuxPage();
});

nokosLink.addEventListener('click', function(e) {
    e.preventDefault();
    showNokosPage();
});

footerApkLink.addEventListener('click', function(e) {
    e.preventDefault();
    showApkPage();
});

footerScriptLink.addEventListener('click', function(e) {
    e.preventDefault();
    showScriptBotPage();
});

footerPresetLink.addEventListener('click', function(e) {
    e.preventDefault();
    showPresetPage();
});

footerSuntikLink.addEventListener('click', function(e) {
    e.preventDefault();
    showSuntikSosmedPage();
});

footerFreeFireLink.addEventListener('click', function(e) {
    e.preventDefault();
    showFreeFirePage();
});

footerRobuxLink.addEventListener('click', function(e) {
    e.preventDefault();
    showRobuxPage();
});

footerNokosLink.addEventListener('click', function(e) {
    e.preventDefault();
    showNokosPage();
});

allProductsLink.addEventListener('click', function(e) {
    e.preventDefault();
    backToMain();
});

backToMainApk.addEventListener('click', function(e) {
    e.preventDefault();
    backToMain();
});

backToMainScript.addEventListener('click', function(e) {
    e.preventDefault();
    backToMain();
});

backToMainPreset.addEventListener('click', function(e) {
    e.preventDefault();
    backToMain();
});

backToMainSuntik.addEventListener('click', function(e) {
    e.preventDefault();
    backToMain();
});

backToMainFreeFire.addEventListener('click', function(e) {
    e.preventDefault();
    backToMain();
});

backToMainRobux.addEventListener('click', function(e) {
    e.preventDefault();
    backToMain();
});

backToMainNokos.addEventListener('click', function(e) {
    e.preventDefault();
    backToMain();
});

closeModal.addEventListener('click', closePaymentModal);

// Close modal when clicking outside the modal content
window.addEventListener('click', function(event) {
    if (event.target === paymentModal) {
        closePaymentModal();
    }
});

// Whatsapp button functionality
whatsappButton.addEventListener('click', function() {
    const whatsappUrl = `https://wa.me/6285763078368?text=Saya%20Sudah%20Tf%20untuk%20pembelian%20di%20Puts%20Store`;
    window.open(whatsappUrl, '_blank');
});

// Initialize
generateApkProducts();
generateScriptBotProducts();
generatePresetProducts();
generateSuntikSosmedProducts();
generateFreeFireProducts();
generateRobuxProducts();
generateNokosProducts();

// Animasi untuk tombol "Add to Cart" di halaman utama
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function() {
        const cartCount = document.querySelector('.cart-count');
        let count = parseInt(cartCount.textContent);
        cartCount.textContent = count + 1;
        
        // Animasi feedback
        this.innerHTML = '<i class="fas fa-check"></i> Ditambahkan';
        this.style.backgroundColor = '#28a745';
        
        setTimeout(() => {
            this.innerHTML = '<i class="fas fa-cart-plus"></i> Beli';
            this.style.backgroundColor = '';
        }, 1500);
    });
});

// Animasi untuk kategori sidebar
document.querySelectorAll('.category-list a').forEach(link => {
    if (!['apk-premium-link', 'script-bot-link', 'preset-link', 'suntik-sosmed-link', 'free-fire-link', 'robux-link', 'nokos-link'].includes(link.id)) {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelector('.active-category').classList.remove('active-category');
            this.classList.add('active-category');
        });
    }
});

// Expose toggleDetail to global scope
  window.toggleDetail = toggleDetail;